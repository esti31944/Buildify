import React from "react";

export default function Loader() {
  return <div style={{ padding: 20 }}>טוען...</div>;
}
